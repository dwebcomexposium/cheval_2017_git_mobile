/* $(document).ready(function(){

  $('.front .list-grids-with-pagin .grid-la-list').slick({
    infinite: true,
   track: function() { return $(this).children('grid-la-list'); },
    slidesToScroll: 3,
    centerMode: true,
    centerPadding: '0px',
    slidesToShow: 3,
    responsive: [
      {
        breakpoint: 768,
        settings: {
          arrows: false,
          centerMode: true,
          centerPadding: '0px',
          slidesToShow: 3
        }
      },
      {
        breakpoint: 480,
        settings: {
          arrows: false,
          centerMode: true,
          centerPadding: '0px',
          slidesToShow: 1
        }
      }
    ]
  });

}); */